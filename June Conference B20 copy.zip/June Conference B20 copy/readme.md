# Reminders AI App

A simple, beginner-friendly reminders app for the elderly and disabled, featuring an AI chatbot for companionship and easy reminder creation.

## Features
- Add, view, and delete reminders
- Chatbot for friendly conversation and creating reminders via chat
- Simple, accessible text interface


## AI Integration
- The chatbot can chat for companionship and recognize phrases like 'remind me to...' to create reminders.
- For richer conversation, I can add my OpenAI API key in `chatbot.py`.