//
//  ContentView.swift
//  SAP Challenge 1
//
//  Created by Veera on 2/6/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = CoursesViewModel()
    
    var body: some View {
        TabView {
            HomeView(viewModel: viewModel)
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
            ExploreView(viewModel: viewModel)
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text("Explore")
                }
        }
    }
}

#Preview {
    ContentView()
}
