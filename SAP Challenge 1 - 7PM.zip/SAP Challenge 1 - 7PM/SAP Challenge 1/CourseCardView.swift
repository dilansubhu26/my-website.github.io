//
//  CourseCardView.swift
//  SAP Challenge 1
//
//  Created by Veera on 2/6/25.
//

import SwiftUI

struct CourseCardView: View {
    let course: Course
    
    private func getCardColor() -> Color {
        switch course.category {
        case "Code": return Color.blue.opacity(0.1)
        case "Music": return Color.purple.opacity(0.1)
        case "Design": return Color.pink.opacity(0.1)
        case "Business": return Color.orange.opacity(0.1)
        case "Engineering": return Color.green.opacity(0.1)
        case "Media": return Color.red.opacity(0.1)
        case "Security": return Color.gray.opacity(0.1)
        default: return Color.blue.opacity(0.1)
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(course.title)
                        .font(.headline)
                        .foregroundColor(.primary)
                    Text(course.provider)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                Spacer()
                Image(systemName: getCategoryIcon())
                    .font(.title2)
                    .foregroundColor(getIconColor())
            }
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(course.tags, id: \.self) { tag in
                        Text(tag)
                            .font(.caption)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(getTagColor(tag))
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                    
                    Text(course.hours)
                        .font(.caption)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.purple.opacity(0.2))
                        .foregroundColor(.purple)
                        .cornerRadius(8)
                    
                    Text(course.ageGroup)
                        .font(.caption)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.orange.opacity(0.2))
                        .foregroundColor(.orange)
                        .cornerRadius(8)
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(getCardColor())
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(getCardColor().opacity(0.5), lineWidth: 2)
        )
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
    
    private func getCategoryIcon() -> String {
        switch course.category {
        case "Code": return "laptopcomputer"
        case "Music": return "music.note"
        case "Design": return "paintbrush"
        case "Business": return "chart.bar"
        case "Engineering": return "gear"
        case "Media": return "video"
        case "Security": return "lock.shield"
        default: return "book"
        }
    }
    
    private func getIconColor() -> Color {
        switch course.category {
        case "Code": return .blue
        case "Music": return .purple
        case "Design": return .pink
        case "Business": return .orange
        case "Engineering": return .green
        case "Media": return .red
        case "Security": return .gray
        default: return .blue
        }
    }
    
    private func getTagColor(tag: String) -> Color {
        switch tag {
        case "Coding": return .blue
        case "Music": return .purple
        case "Industry": return .orange
        case "Design": return .pink
        case "Web Dev": return .green
        case "Data Science": return .blue
        case "Game Dev": return .purple
        case "Marketing": return .orange
        case "Creation": return .red
        default: return .gray
        }
    }
}
