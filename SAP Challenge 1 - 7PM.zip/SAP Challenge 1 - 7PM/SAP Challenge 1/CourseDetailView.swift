//
//  CourseDetailView.swift
//  SAP Challenge 1
//
//  Created by Veera on 2/6/25.
//

import SwiftUI

struct CourseDetailView: View {
    let course: Course
    
    var calendarURL: URL {
        if course.title == "Swift Accelerator" {
            return URL(string: "https://www.icloud.com/calendar")!
        } else if course.title == "GarageBand Music Creation" {
            return URL(string: "https://www.icloud.com/calendar")!
        } else {
            return URL(string: "https://www.icloud.com/calendar")!
        }
    }
    
    var signupURL: URL {
        if course.title == "Swift Accelerator" {
            return URL(string: "https://www.swiftinsg.org")!
        } else if course.title == "GarageBand Music Creation" {
            return URL(string: "https://www.apple.com/sg/today/")!
        } else {
            return URL(string: "https://www.codecademy.com")!
        }
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text(course.title)
                    .font(.largeTitle).bold()
                Text(course.provider)
                    .font(.title3)
                HStack {
                    ForEach(course.tags, id: \.self) { tag in
                        TagView(text: tag, color: .gray)
                    }
                }
                Text(course.description)
                Text("Address: \(course.address)\nFrequency: \(course.frequency)\nTotal hrs: \(course.totalHours)")
                    .font(.subheadline)
                VStack(spacing: 12) {
                    Link(destination: calendarURL) {
                        Text("Calendar Dates")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 16).stroke(Color.orange, lineWidth: 2))
                    }
                    Link(destination: signupURL) {
                        Text("Sign Up")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 16).fill(Color.yellow.opacity(0.7)))
                    }
                }
            }
            .padding()
        }
    }
}
