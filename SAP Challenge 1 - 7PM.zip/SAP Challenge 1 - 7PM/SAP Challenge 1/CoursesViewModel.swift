//
//  CoursesViewModel.swift
//  SAP Challenge 1
//
//  Created by Veera on 2/6/25.
//

import SwiftUI

class CoursesViewModel: ObservableObject {
    @Published var completedCourseIDs: Set<UUID> = []
    let courses: [Course] = sampleCourses

    var progress: Double {
        guard !courses.isEmpty else { return 0 }
        return Double(completedCourseIDs.count) / Double(courses.count) 
    }

    func toggleCompleted(for course: Course) {
        withAnimation {
            if completedCourseIDs.contains(course.id) {
                completedCourseIDs.remove(course.id)
            } else {
                completedCourseIDs.insert(course.id)
            }
        }
    }

    func isCompleted(_ course: Course) -> Bool {
        completedCourseIDs.contains(course.id)
    }
}
