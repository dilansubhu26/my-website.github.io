//
//  HomeView.swift
//  SAP Challenge 1
//
//  Created by Veera on 2/6/25.
//

import SwiftUI

struct HomeView: View {
    @ObservedObject var viewModel: CoursesViewModel

    var body: some View {
        NavigationStack {
            List {
                // Header Section
                Group {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Welcome back!")
                            .font(.system(size: 34, weight: .bold))
                            .foregroundColor(.primary)
                        Text("Track your learning journey")
                            .font(.title3)
                            .foregroundColor(.secondary)
                    }
                    .padding(.horizontal)
                    .padding(.top)
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets())
                    
                    ProgressViewSection(progress: viewModel.progress)
                        .padding(.horizontal)
                        .padding(.top, 24)
                        .background(Color(UIColor.systemBackground))
                        .cornerRadius(20)
                        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                        .listRowInsets(EdgeInsets())
                    
                    Text("Your current courses")
                        .font(.title2.bold())
                        .padding(.horizontal)
                        .padding(.top, 24)
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                        .listRowInsets(EdgeInsets())
                }
                
                // Current Courses
                ForEach(viewModel.courses.filter { !viewModel.isCompleted($0) }) { course in
                    NavigationLink(destination: CourseDetailView(course: course)) {
                        CourseCardView(course: course)
                    }
                    .padding(.vertical, 8)
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16))
                    .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                        Button {
                            withAnimation {
                                viewModel.toggleCompleted(for: course)
                            }
                        } label: {
                            Label("Complete", systemImage: "checkmark.circle.fill")
                        }
                        .tint(.green)
                    }
                }
                
                // Completed Courses Section
                if !viewModel.courses.filter({ viewModel.isCompleted($0) }).isEmpty {
                    Text("Completed Courses")
                        .font(.title2.bold())
                        .padding(.horizontal)
                        .padding(.top, 24)
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                        .listRowInsets(EdgeInsets())
                    
                    ForEach(viewModel.courses.filter { viewModel.isCompleted($0) }) { course in
                        NavigationLink(destination: CourseDetailView(course: course)) {
                            CourseCardView(course: course)
                                .opacity(0.8)
                        }
                        .padding(.vertical, 8)
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                        .listRowInsets(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16))
                        .swipeActions(edge: .leading, allowsFullSwipe: true) {
                            Button {
                                withAnimation {
                                    viewModel.toggleCompleted(for: course)
                                }
                            } label: {
                                Label("Undo", systemImage: "arrow.uturn.left.circle.fill")
                            }
                            .tint(.blue)
                        }
                    }
                }
            }
            .listStyle(PlainListStyle())
            .background(Color(UIColor.systemGroupedBackground))
        }
    }
}
