//
//  ProgressViewSection.swift
//  SAP Challenge 1
//
//  Created by Veera on 2/6/25.
//

import SwiftUI

struct ProgressViewSection: View {
    var progress: Double
    
    var body: some View {
        VStack {
            Text("Your Progress")
                .font(.subheadline)
            ProgressView(value: progress)
                .progressViewStyle(LinearProgressViewStyle(tint: .blue))
                .frame(height: 20)
                .padding(.horizontal)
            Text("\(Int(progress * 100))% completed")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}
