//
//  TagView.swift
//  SAP Challenge 1
//
//  Created by Dilan Subhu Veerappan on 3/6/25.
//

import SwiftUI

struct TagView: View {
    let text: String
    let color: Color
    var body: some View {
        Text(text)
            .font(.caption)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(color.opacity(0.2))
            .foregroundColor(color)
            .cornerRadius(8)
    }
}

